400 - BadRequest
----------------

.. csv-table::
    :file: ../../../../compiler/errors/source/400_BAD_REQUEST.tsv
    :delim: tab
    :header-rows: 1
