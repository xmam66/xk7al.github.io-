403 - Forbidden
---------------

.. csv-table::
    :file: ../../../../compiler/errors/source/403_FORBIDDEN.tsv
    :delim: tab
    :header-rows: 1